import { pureGet } from "../common/ajax";

export const get = () => pureGet("/sdnu/news");
