let Config = {};

Config.backEndUrl = "http://124.221.54.208:8085";

export default Config;
