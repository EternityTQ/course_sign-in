module.exports = {
  devServer: {
    host: '0.0.0.0',
    public: '124.221.54.208:8080',
    disableHostCheck: true
  }
};


